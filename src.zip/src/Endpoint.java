/**
 * Created by S. Stefani on 2017-02-23.
 */
public class Endpoint {
    public int latency;
    public int [] cachesId;
    public int [] cachesLatency;

}
