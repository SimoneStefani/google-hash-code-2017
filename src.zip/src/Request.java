/**
 * Created by S. Stefani on 2017-02-23.
 */
public class Request {
    public int video;
    public int endpoint;
    public int requests;
}
